document.addEventListener('DOMContentLoaded', function(){



let open = document.querySelectorAll('.open_modal'),
      open_modal = document.querySelector('.modal');
      open.forEach((open_mod,i) => {
      open_mod.addEventListener("click", function () {
          let open_mod_index = open[i];
          open_modal.classList.add('modal-show');
          document.body.style.overflow = 'hidden';
        
  })
});

let  close_modal =  document.querySelector('.close-modal');
     close_modal.addEventListener("click", function () {
     open_modal.classList.remove('modal-show');
      document.body.style.overflow = 'auto';
 })


const form = document.querySelector('.card-form-modal');
let formSubmit = document.querySelector('.card-button-send');
let card_item =   document.querySelectorAll('.сard-item button a');
let span_item =  document.querySelectorAll('.сard-item .сard-deskription-title span');
let text_price = document.querySelector('.text-price  p');
let text_price_input = document.querySelector('#text-price-id-input');


card_item.forEach((staffDetail,index) => {
  staffDetail.addEventListener("click", function () {
      let button_index = (index);
       let span_text = span_item[button_index].textContent;
         let t_price = text_price;
             text_price.innerHTML = span_text;
            console.log(t_price);

       
      })
});


let formInputs = document.querySelectorAll('.js-input'),
    inputName = document.querySelector('.js-input-name'),
    inputPhone = document.querySelector('.js-input-phone'),
    emptyInputs = Array.from(formInputs).filter(input => input.value === '');

form.onsubmit = function () {
  let nameVal = inputName.value,
      phoneVal = inputPhone.value;
     


    formInputs.forEach(function(input){
        if (input.value === ''){
          input.classList.add('modal-error');
          event.preventDefault();
        }else {
          input.classList.remove('modal-error');


}//////else 


  });



     
}

})








