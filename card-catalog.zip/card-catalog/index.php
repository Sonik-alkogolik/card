<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="UTF-8">
    <title>Card Product</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="HandheldFriendly" content="true"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"> </script>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>


<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(89607942, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/89607942" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->


<div class="container">
 <section >
   <div id="openModal" class="modal">
    <div class="modal-dialog">
       <div class="modal-content">
        <div class="modal-header">
          <h3 >Форма карточки</h3>
          <a title="Close" class="close-modal">×</a>
        </div>
        <div class="modal-body">
          <form class="card-form-modal" name="form" method="post" action="">
          <input class="input js-input js-input-name" type="text" name="name" value="" placeholder="Ваше имя">
          <input class="input js-input js-input-phone" type="number" name="tel" value=""  placeholder="Ваш телефон">
          <div class="text-price">
          <span>Ваш заказ:</span><p name="text-price"></p>
          </div>
          <button onclick="ym(89607942,'reachGoal','card_btn')"class="card-button-send" type="submit" >Отправить</button>  
          </form>
        </div>
      </div>
    </div>
  </div>
 </section>
</div>
<div class="container">
  <section>
    <div class="сard-wrap">
      <div class="сard-item">
        <div class="сard-img">
          <img src="./img/nike-white.jpg" alt="img-сard">
        </div>
        <div class="сard-deskription">
          <div class="сard-deskription-title">
            <span>Белая футблока nike</span>
            <p>500 р/шт</p>
          </div>
          <div class="card-button">
            <button ><a class="open_modal">Купить</a></button>
          </div>
        </div>
      </div>
      <div class="сard-item">
        <div class="сard-img">
          <img src="./img/nike-black.jpg" alt="img-сard">
        </div>
        <div class="сard-deskription">
          <div class="сard-deskription-title">
            <span>Чёрная футблока nike</span>
            <p>500 р/шт</p>
          </div>
          <div class="card-button">
            <button><a class="open_modal">Купить</a></button>
          </div>
        </div>
      </div>
      <div class="сard-item">
        <div class="сard-img">
          <img src="./img/nike-green.jpg" alt="img-сard">
        </div>
        <div class="сard-deskription">
          <div class="сard-deskription-title">
            <span>Зелёная  футблока nike</span>
            <p>500 р/шт</p>
          </div>
          <div class="card-button">
            <button><a class="open_modal">Купить</a></button>
          </div>
        </div>
      </div>
      <div class="сard-item">
        <div class="сard-img">
          <img src="./img/nike-red.jpg" alt="img-сard">
        </div>
        <div class="сard-deskription">
          <div class="сard-deskription-title">
            <span>Красная футблока nike</span>
            <p>500 р/шт</p>
          </div>
          <div class="card-button">
            <button><a class="open_modal">Купить</a></button>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>


<script src="modal.js"></script>
<script src="ajax.js"></script>
 </body>
</html>
       