<?php 

$string = file_get_contents('dataJson.json');
$object = json_decode($string);

$name = $_POST['name'];
$tel = $_POST['tel'];

$name = trim($name);
$tel = trim($tel);

if( $string != false && !is_null($object)){
    foreach($object as $k => $e){
       // echo '<p>'  . $e . '</p>';
    }
}
$headers .= "Content-type: text/html; charset=utf-8\r\n";
$mainBody = '
<html>
<body>
<center>
<table border="1" cellpadding="6" cellspacing="0" width = "50%" bordercolor = "#DBDBDB">
<tr><td colspan="2" align="center"><b>Информация о клиенте</b> </td></tr>
';
$mainBody .= '<tr>
<td><b>Имя клиента:</b></td>
<td>'. $name .'</td>
</tr>
<tr>
<td><b>Телефон:</b></td>
<td>'. $tel .'</td>
</tr>
<tr>
<td><b>Наименование:</b></td>
<td>'. $e .'</td>
</tr>';

if (mail("dmitribelitskij@gmail.com", 
    "Заявка с сайта",$mainBody,$headers
    /*
    "Имя:" .$name. "\r\n".
    "Наименование:" .$e. "\r\n".
    "Телефон:" .$tel."\r\n".
    "Заказ от : dmitribelitskij@gmail.com"*/ ))
{   

    echo "<br>";
    echo "Ваш заказ принят";
    echo "<br>";
    echo $name ;
    echo "<br>";
    echo $tel;
    echo "<br>";
    echo $e ;
    
} else {
    echo "при отправке заявки возникли ошибки";
}




?>
<script type="text/javascript">
 
  setTimeout(function() {
window.location.href = "index.php";
}, 500);

</script>