<?php

$stringJson = file_put_contents('dataJson.json', $_POST['myJson']);

?>
