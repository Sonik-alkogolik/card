let form = $(".card-form-modal");
let name = $(".js-input-name");
let tel = $(".js-input-phone");
let text_price = $(".text-price p");
let card_btn = $(".card-button button a");
let card_title = $(".сard-deskription-title span");
let card_btn_send = $(".card-button-send");

 

	card_btn.click(function() {
    let card_btn_index = card_btn.index(this);
    let card_span_text = card_title[card_btn_index];
      card_btn_send.click(function() {  
         $.ajax({
       url: 'reed.php',
       type: 'POST',
       data:form.serialize(),
      });
     text_price.each(function(index, p) {
     let arr = [];  
       arr.push($(p).text());
        console.log(arr);
       $.ajax({
       url: 'data.php',
       type: 'POST',
       data: {myJson: JSON.stringify(arr), fileName: 'dataJson.json'},
      });
  
   });
});
  
   });


